self.addEventListener('message', function(e) {
  var data = e.data;
  switch (data) {
    case 'start':
      self.postMessage('WORKER STARTED');
      break;
    case 'stop':
      self.postMessage('WORKER STOPPED. (buttons will no longer work)');
      self.close(); // Terminates the worker.
      break;
    default:
      self.postMessage('Unknown command: ' + data);
  };
}, false);